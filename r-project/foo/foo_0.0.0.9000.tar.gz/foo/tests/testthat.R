library(testthat)
library(foo)

test_check("foo")
